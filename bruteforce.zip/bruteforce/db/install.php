<?php

function xmldb_auth_bruteforce_install() {
    global $CFG, $DB;

}
